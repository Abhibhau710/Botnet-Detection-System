import tkinter as tk
from tkinter import *
import pandas as pd
import numpy as np
import joblib
#from hmmlearn import hmm
from sklearn.preprocessing import LabelEncoder                  #for preprocessing
from sklearn.model_selection import train_test_split                      #split data into traning and testing
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score               # for calculating accuracy and generating classification report
from sklearn.ensemble import VotingClassifier                       #inbuild library for voting algorithm
from sklearn.svm import SVC                      #inbuild library for SVM algorithm
# from PIL import Image, ImageTk
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


from sklearn import model_selection
le = LabelEncoder()     #object creation

root = tk.Tk()                    #rrot object of tkinter

w,h = root.winfo_screenwidth() ,root.winfo_screenheight()                 #calculating screen width and height
print(w,h)
root.geometry("%dx%d+0+0"%(w,h))
root.title("BOTNET DETECTION SYSTEM")
root.configure(background="gray")

ime = None

new_data = pd.read_csv(r'kddcup99_csv.csv') #, sep='COLUMN_SEPARATOR', dtype=np.float64)
new_data = new_data.loc[(new_data['label']=='neptune') | (new_data['label']=='normal') | (new_data['label']=='smurf')]
new_data['protocol_type']=le.fit_transform(new_data['protocol_type'])
new_data['service']=le.fit_transform(new_data['service'])
new_data['flag']=le.fit_transform(new_data['flag'])



x_train = new_data[['protocol_type', 'service', 'flag', 'logged_in', 'count', 'serror_rate',
       'srv_serror_rate', 'rerror_rate', 'srv_rerror_rate', 'same_srv_rate',
       'diff_srv_rate', 'srv_diff_host_rate', 'dst_host_count',
       'dst_host_srv_count', 'dst_host_same_srv_rate',
       'dst_host_diff_srv_rate', 'dst_host_serror_rate',
       'dst_host_srv_serror_rate', 'dst_host_rerror_rate',
       'dst_host_srv_rerror_rate']]
y_train = new_data["label"]
y_train.replace({'normal':0,'neptune':1, 'smurf':2}, inplace=True)



new_data2 = pd.read_csv(r'KDD_CUP_2.csv') #, sep='COLUMN_SEPARATOR', dtype=np.float64)
new_data2 = new_data2.loc[(new_data2['label']=='neptune') | (new_data2['label']=='normal') | (new_data2['label']=='smurf')]
new_data2['protocol_type']=le.fit_transform(new_data2['protocol_type'])
new_data2['service']=le.fit_transform(new_data2['service'])
new_data2['flag']=le.fit_transform(new_data2['flag'])


x_test = new_data2[['protocol_type', 'service', 'flag', 'logged_in', 'count', 'serror_rate',
       'srv_serror_rate', 'rerror_rate', 'srv_rerror_rate', 'same_srv_rate',
       'diff_srv_rate', 'srv_diff_host_rate', 'dst_host_count',
       'dst_host_srv_count', 'dst_host_same_srv_rate',
       'dst_host_diff_srv_rate', 'dst_host_serror_rate',
       'dst_host_srv_serror_rate', 'dst_host_rerror_rate',
       'dst_host_srv_rerror_rate']]
y_test = new_data2["label"]


ss = StandardScaler()
x_train = pd.DataFrame(data=ss.fit_transform(x_train), columns=x_train.columns)
x_test = pd.DataFrame(data=ss.fit_transform(x_test), columns=x_test.columns)


pca = PCA(n_components=5)
x_train = pca.fit_transform(x_train)
cols = [f'PC{i}' for i in range(1,6)]
x_train = pd.DataFrame(data=x_train, columns=cols)
x_test = pd.DataFrame(data=pca.transform(x_test), columns=cols)

from xgboost import XGBClassifier              #inbuild library for XG Bosst  algorithm


def XG_BOOST():
    
    
    label_counts = new_data['label'].value_counts()
    desired_counts = (label_counts / len(new_data) * 40000).round().astype(int)

    smaller_df = pd.DataFrame(columns=new_data.columns)
    for label, count in desired_counts.items():
        subset = new_data[new_data['label'] == label].sample(n=count, random_state=42)
        smaller_df = smaller_df.append(subset)

    x_train = smaller_df[['protocol_type', 'service', 'flag', 'logged_in', 'count', 'serror_rate',
       'srv_serror_rate', 'rerror_rate', 'srv_rerror_rate', 'same_srv_rate',
       'diff_srv_rate', 'srv_diff_host_rate', 'dst_host_count',
       'dst_host_srv_count', 'dst_host_same_srv_rate',
       'dst_host_diff_srv_rate', 'dst_host_serror_rate',
       'dst_host_srv_serror_rate', 'dst_host_rerror_rate',
       'dst_host_srv_rerror_rate']]
    y_train = smaller_df["label"]

    ss = StandardScaler()
    x_train = pd.DataFrame(data=ss.fit_transform(x_train), columns=x_train.columns)


    pca = PCA(n_components=5)
    x_train = pca.fit_transform(x_train)
    cols = [f'PC{i}' for i in range(1,6)]
    x_train = pd.DataFrame(data=x_train, columns=cols)

    model1 = XGBClassifier(n_estimators = 400, learning_rate = 0.1, max_depth = 3)

    y_train.replace({'normal':0,'neptune':1, 'smurf':2}, inplace=True)
    model1.fit(x_train, y_train)
    
    model1_pred = model1.predict(x_test)
    print(model1_pred)
    model1_pred = np.vectorize({0:'normal',1:'neptune', 2:'smurf'}.get)(model1_pred)
    
    
    print("=" * 40)
    print("==========")
    print("Classification Report : ",(classification_report(y_test, model1_pred)))
    print("Accuracy : ",accuracy_score(y_test,model1_pred)*100)
    accuracy = accuracy_score(y_test, model1_pred)
    print("Accuracy: %.2f%%" % (accuracy * 100.0))
    ACC = round(accuracy_score(y_test, model1_pred) * 100, 2)
    repo = (classification_report(y_test, model1_pred))
    
    label4 = tk.Label(root,text =str(repo),width=40,height=10,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label4.place(x=305,y=100)
    
    label5 = tk.Label(root,text ="Accuracy : "+str(ACC)+"%\nModel saved as XG_BOOST.joblib",width=40,height=3,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label5.place(x=305,y=320)
    from joblib import dump
    dump (model1,"XG_BOOST.joblib")
    print("Model saved as XG_BOOST.joblib")


def SVM():

    label_counts = new_data['label'].value_counts()
    desired_counts = (label_counts / len(new_data) * 50).round().astype(int)

    smaller_df = pd.DataFrame(columns=new_data.columns)
    for label, count in desired_counts.items():
        subset = new_data[new_data['label'] == label].sample(n=count, random_state=42)
        smaller_df = smaller_df.append(subset)

    x_train = smaller_df[['protocol_type', 'service', 'flag', 'logged_in', 'count', 'serror_rate',
       'srv_serror_rate', 'rerror_rate', 'srv_rerror_rate', 'same_srv_rate',
       'diff_srv_rate', 'srv_diff_host_rate', 'dst_host_count',
       'dst_host_srv_count', 'dst_host_same_srv_rate',
       'dst_host_diff_srv_rate', 'dst_host_serror_rate',
       'dst_host_srv_serror_rate', 'dst_host_rerror_rate',
       'dst_host_srv_rerror_rate']]
    y_train = smaller_df["label"]

    ss = StandardScaler()
    x_train = pd.DataFrame(data=ss.fit_transform(x_train), columns=x_train.columns)


    pca = PCA(n_components=5)
    x_train = pca.fit_transform(x_train)
    cols = [f'PC{i}' for i in range(1,6)]
    x_train = pd.DataFrame(data=x_train, columns=cols)

    model2 = SVC(kernel='linear', random_state = 60, C=0.02)  
    y_train.replace({'normal':0,'neptune':1, 'smurf':2}, inplace=True)
    model2.fit(x_train, y_train)
    
    # model2 = SVC(kernel='linear', random_state = 2)  
    # model2.fit(x_train, y_train)
    
    
    print("=" * 40)
    # print(model2_pred)
    model2_pred = model2.predict(x_test)
    model2_pred = np.vectorize({0:'normal',1:'neptune', 2:'smurf'}.get)(model2_pred)
    
    print("=" * 40)
    print("==========")
    print("Classification Report : ",(classification_report(y_test, model2_pred)))
    print("Accuracy : ",accuracy_score(y_test,model2_pred)*100)
    accuracy = accuracy_score(y_test, model2_pred)
    print("Accuracy: %.2f%%" % (accuracy * 100.0))
    ACC = round(accuracy_score(y_test, model2_pred) * 100, 2)
    repo = (classification_report(y_test, model2_pred))
    
    label4 = tk.Label(root,text =str(repo),width=40,height=10,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label4.place(x=305,y=100)
    
    label5 = tk.Label(root,text ="Accuracy : "+str(ACC)+"%\nModel saved as SVM.joblib",width=40,height=3,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label5.place(x=305,y=320)
    from joblib import dump
    dump (model2,"SVM.joblib")
    print("Model saved as SVM.joblib")
    
from sklearn.tree import DecisionTreeClassifier              #inbuild library for Decision tree algorithm

def DT():
    
    model4 = DecisionTreeClassifier(criterion = "gini",random_state = 100,max_depth=3, min_samples_leaf=5)   
    
    model4.fit(x_train, y_train)
    
    
    
    print("=" * 40)
    model4.fit(x_train, y_train)
    
    model4_pred = model4.predict(x_test)
    #print(model2_pred)
    model4_pred = np.vectorize({0:'normal',1:'neptune', 2:'smurf'}.get)(model4_pred)
    
    
    print("=" * 40)
    print("==========")
    print("Classification Report : ",(classification_report(y_test, model4_pred)))
    print("Accuracy : ",accuracy_score(y_test,model4_pred)*100)
    accuracy = accuracy_score(y_test, model4_pred)
    print("Accuracy: %.2f%%" % (accuracy * 100.0))
    ACC = round(accuracy_score(y_test, model4_pred) * 100, 2)
    repo = (classification_report(y_test, model4_pred))
    
    label4 = tk.Label(root,text =str(repo),width=40,height=10,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label4.place(x=305,y=100)
    
    label5 = tk.Label(root,text ="Accuracy : "+str(ACC)+"%\nModel saved as DT.joblib",width=40,height=3,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label5.place(x=305,y=320)
    from joblib import dump
    dump (model4,"DT.joblib")
    print("Model saved as DT.joblib")

  
    
from sklearn.ensemble import RandomForestClassifier                 #inbuild library for Random Forest algorithm
    
def RF():
    
    model5 = RandomForestClassifier(n_estimators=50,max_depth=3,max_features=3,random_state=42)

    model5.fit(x_train, y_train)
    
    model5_pred = model5.predict(x_test)
    print(model5_pred)
    model5_pred = np.vectorize({0:'normal',1:'neptune', 2:'smurf'}.get)(model5_pred)
    
    print("=" * 40)
    print("==========")
    print("Classification Report : ",(classification_report(y_test, model5_pred)))
    print("Accuracy : ",accuracy_score(y_test,model5_pred)*100)
    accuracy = accuracy_score(y_test, model5_pred)
    print("Accuracy: %.2f%%" % (accuracy * 100.0))
    ACC = round(accuracy_score(y_test, model5_pred) * 100, 2)
    repo = (classification_report(y_test, model5_pred))
    
    label4 = tk.Label(root,text =str(repo),width=40,height=10,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label4.place(x=305,y=100)
    
    label5 = tk.Label(root,text ="Accuracy : "+str(ACC)+"%\nModel saved as RF.joblib",width=40,height=3,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label5.place(x=305,y=320)
    from joblib import dump
    dump(model5,"RF.joblib")
    print("Model saved as RF.joblib")

 
from sklearn.naive_bayes import GaussianNB               #inbuild library for Naivy bayes algorithm
    
def NB():
    
    model3 = GaussianNB()
    model3.fit(x_train, y_train)
    
    
    
    print("=" * 40)
    
    model3_pred = model3.predict(x_test)
    model3_pred = np.vectorize({0:'normal',1:'neptune', 2:'smurf'}.get)(model3_pred)
      
    
    print("=" * 40)
    print("==========")
    print("Classification Report : ",(classification_report(y_test, model3_pred)))
    print("Accuracy : ",accuracy_score(y_test,model3_pred)*100)
    accuracy = accuracy_score(y_test, model3_pred)
    print("Accuracy: %.2f%%" % (accuracy * 100.0))
    ACC = round(accuracy_score(y_test, model3_pred) * 100, 2)
    repo = (classification_report(y_test, model3_pred))
    
    label4 = tk.Label(root,text =str(repo),width=40,height=10,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label4.place(x=305,y=100)
    
    label5 = tk.Label(root,text ="Accuracy : "+str(ACC)+"%\nModel saved as NB.joblib",width=40,height=3,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label5.place(x=305,y=320)
    from joblib import dump
    dump (model3,"NB.joblib")
    print("Model saved as NB.joblib")



def VE():

    # model1 = joblib.load('XG_BOOST.joblib')
    # # model4 = joblib.load('DT.joblib')   
    # model2 = joblib.load('SVM.joblib')  
    # model5 = joblib.load('RF.joblib')
    # model6 = VotingClassifier(estimators=[('rf', model5),('xgb',model1),('svc',model2)], voting='hard')
    
    
    
    
    # print("=" * 40)
    # model6.fit(x_train, y_train)
    
    # model6_pred = model6.predict(x_test)
    # #print(model2_pred)
    # model6_pred = np.vectorize({0:'normal',1:'neptune', 2:'smurf'}.get)(model6_pred)
    
    # print("=" * 40)
    # print("==========")
    # print("Classification Report : ",(classification_report(y_test, model6_pred)))
    # print("Accuracy : ",accuracy_score(y_test,model6_pred)*100)
    # accuracy = accuracy_score(y_test, model6_pred)
    # print("Accuracy: %.2f%%" % (accuracy * 100.0))
    # ACC = round(accuracy_score(y_test, model6_pred) * 100, 2)
    # repo = (classification_report(y_test, model6_pred))
    
    # label4 = tk.Label(root,text =str(repo),width=40,height=10,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    # label4.place(x=305,y=100)
    
    # label5 = tk.Label(root,text ="Accuracy : "+str(ACC)+"%\nModel saved as VE.joblib",width=40,height=3,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    # label5.place(x=305,y=320)
    # from joblib import dump
    # dump (model6,"VE.joblib")
    # print("Model saved as VE.joblib")

    model6 = joblib.load('VE.joblib')
    model6_pred = model6.predict(x_test)
    #print(model2_pred)
    model6_pred = np.vectorize({0:'normal',1:'neptune', 2:'smurf'}.get)(model6_pred)
    
    print("=" * 40)
    print("==========")
    print("Classification Report : ",(classification_report(y_test, model6_pred)))
    print("Accuracy : ",accuracy_score(y_test,model6_pred)*100)
    accuracy = accuracy_score(y_test, model6_pred)
    print("Accuracy: %.2f%%" % (accuracy * 100.0))
    ACC = round(accuracy_score(y_test, model6_pred) * 100, 2)
    repo = (classification_report(y_test, model6_pred))
    
    label4 = tk.Label(root,text =str(repo),width=40,height=10,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label4.place(x=305,y=100)
    
    label5 = tk.Label(root,text ="Accuracy : "+str(ACC)+"%\nModel saved as VE.joblib",width=40,height=3,bg='black',fg='white',font=("Tempus Sanc ITC",14))
    label5.place(x=305,y=320)

    
def EXIT():
    root.destroy()



frame = tk.LabelFrame(root,text="Control Panel",width=200,height=500,bd=1,background="black",font=("Tempus Sanc ITC",15,"bold"))
frame.place(x=5,y=50)

button1 = tk.Button(frame,command=XG_BOOST,text="XG_BOOST",bg="white",fg="black",width=15,font=("Times New Roman",15,"italic"))
button1.place(x=5,y=1)

button2 = tk.Button(frame,command=SVM,text="SVM",bg="white",fg="black",width=15,font=("Times New Roman",15,"italic"))
button2.place(x=5,y=50)

button3 = tk.Button(frame,command=NB,text="Naive Bayes",bg="white",fg="black",width=15,font=("Times New Roman",15,"italic"))
button3.place(x=5,y=100)   #y=100

button4 = tk.Button(frame,command=DT,text="Decision Tree",bg="white",fg="black",width=15,font=("Times New Roman",15,"italic"))
button4.place(x=5,y=150)

button5 = tk.Button(frame,command=RF,text="Random Forest",bg="white",fg="black",width=15,font=("Times New Roman",15,"italic"))
button5.place(x=5,y=200)

button6 = tk.Button(frame,command=VE,text="Voting Ensemble",bg="white",fg="black",width=15,font=("Times New Roman",15,"italic"))
button6.place(x=5,y=250)

state=tk.IntVar()
myCombobox=""

from tkinter import ttk
State_Name ={"XG_BOOST":1,"NAIVE BAYES":2,"DECISION TREE":3,"RANDOM FOREST":4, "SUPPORT VECTOR MACHINE":5,"VOTING ENSEMBLE":6} #{"XG_BOOST":1,"SUPPORT VECTOR MACHINE":2,"NAIVE BAYES":3,"DECISION TREE":4,"RANDOM FOREST":5,"VOTING ENSEMBLE":6}
myCombobox=ttk.Combobox(frame,values=list(State_Name.keys()),width=25,textvariable = state)
myCombobox.state(['readonly'])
myCombobox.bind("<<ComboboxSelected>>", lambda event: print(State_Name[myCombobox.get()]))

myCombobox.current(0)
myCombobox.place(x=5,y=320)

# model_list = {"XG_BOOST":"D:\test\IDS_5_CLASSIFIERS2\OLD_MODELS/XG_BOOST.joblib",
#               "SUPPORT VECTOR MACHINE":"D:\test\IDS_5_CLASSIFIERS2\OLD_MODELS/SVM.joblib",
#               "NAIVE BAYES":"D:\test\IDS_5_CLASSIFIERS2\OLD_MODELS/NB.joblib",
#               "DECISION TREE":"IDS_5_CLASSIFIERS2\DT.joblib",
#               "RANDOM FOREST":"D:\test\IDS_5_CLASSIFIERS2\OLD_MODELS/RF.joblib",
#               "VOTING ENSEMBLE":"D:\test\IDS_5_CLASSIFIERS2\OLD_MODELS/VE.joblib"
#               }

model_list = {
    "XG_BOOST":r'XG_BOOST.joblib',
    "SUPPORT VECTOR MACHINE":r'SVM.joblib',
    "DECISION TREE":r'DT.joblib',
    "RANDOM FOREST":r'RF.joblib',
    "VOTING ENSEMBLE":r'VE.joblib',
    "NAIVE BAYES":r'NB.joblib'
    }

def ok():
    
    print ("value is:" + myCombobox.get())
    model_choice = myCombobox.get()
    choosen_model = model_list[model_choice]
    print(choosen_model)
    from joblib import load
    ans = load(choosen_model)
    
    from tkinter.filedialog import askopenfilename
    fileName = askopenfilename(initialdir='D:\Botnet detection system/', title='Select DataFile For BOTNET Testing',
                                       filetypes=[("all files", "*.csv*")])
    
    file =pd.read_csv(fileName)
    file['protocol_type']=le.fit_transform(file['protocol_type'])
    file['service']=le.fit_transform(file['service'])
    file['flag']=le.fit_transform(file['flag'])

    # qn = file.drop(["label"],axis=1)
    model_test = file[['protocol_type', 'service', 'flag', 'logged_in', 'count', 'serror_rate',
       'srv_serror_rate', 'rerror_rate', 'srv_rerror_rate', 'same_srv_rate',
       'diff_srv_rate', 'srv_diff_host_rate', 'dst_host_count',
       'dst_host_srv_count', 'dst_host_same_srv_rate',
       'dst_host_diff_srv_rate', 'dst_host_serror_rate',
       'dst_host_srv_serror_rate', 'dst_host_rerror_rate',
       'dst_host_srv_rerror_rate']]

    cols = [f'PC{i}' for i in range(1,6)]
    model_test = pd.DataFrame(data=pca.transform(ss.transform(model_test)), columns=cols)
    
    # print(qn)
    result = ans.predict(model_test)
    result = np.vectorize({0:'normal',1:'neptune', 2:'smurf'}.get)(result)

    def listToString(s): 
    
        val = 1
        
        # traverse in the string  
        for ele in s: 
            if ele == 'neptune' or ele == 'smurf':
                val = 0
                break
        
        return val 
    
    print(listToString(result)) 
    final_result = listToString(result)
    print("final result is ",final_result)
    if final_result == 0:   
        output = 'Botnet Detected'
    else:
        output = 'Botnet Not Detected'
    
    attack = tk.Label(root,text=str(output),width=30,bg='red',fg='white',font=("Times New Roman",20,'italic'))
    attack.place(x=170,y=550)
    
        
    

button7 = tk.Button(frame,command=ok,text="TEST",bg="white",fg="black",width=15,font=("Times New Roman",15,"italic"))
button7.place(x=5,y=350)

button8 = tk.Button(frame,command=EXIT,text="EXIT",bg="red",fg="black",width=15,font=("Times New Roman",15,"italic"))
button8.place(x=5,y=400)




head = tk.Label(root,text = "BOTNET DETECTION SYSTEM",width=100,height=1,bg='black',fg='white',font=("Tempus Sanc ITC",18,"italic"))
head.place(x=0,y=0)



root.mainloop()



